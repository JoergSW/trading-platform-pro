from abc import ABC, abstractmethod

class UnitOfWork(ABC):
    @abstractmethod
    def commit(self): ...
    @abstractmethod
    def rollback(self): ...
