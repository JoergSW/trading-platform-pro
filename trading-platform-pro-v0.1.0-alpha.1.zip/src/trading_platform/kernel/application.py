from .dependency_container import Container
from .lifecycle import State

class Application:
    def __init__(self):
        self.container=Container()
        self.state=State.CREATED
    def start(self):
        self.state=State.RUNNING
    def stop(self):
        self.state=State.STOPPED
