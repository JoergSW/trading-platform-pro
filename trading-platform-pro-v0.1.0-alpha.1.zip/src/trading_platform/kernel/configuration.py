from pathlib import Path
import yaml

class Configuration:
    def __init__(self,path:Path):
        self.path=path
        self.data={}
    def load(self):
        with self.path.open("r",encoding="utf-8") as f:
            self.data=yaml.safe_load(f) or {}
        return self.data
