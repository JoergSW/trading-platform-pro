from pathlib import Path
from .application import Application
from .configuration import Configuration
from trading_platform.shared.logging.logger import configure_logging

def bootstrap(config_file:Path):
    configure_logging()
    cfg=Configuration(config_file)
    cfg.load()
    app=Application()
    app.container.register("config",cfg)
    app.start()
    return app
