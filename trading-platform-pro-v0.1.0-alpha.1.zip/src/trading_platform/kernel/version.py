from dataclasses import dataclass

@dataclass(frozen=True)
class VersionInfo:
    name:str="Trading Platform Pro"
    version:str="0.1.0-alpha.1"
    api_version:str="0.1"

VERSION=VersionInfo()
