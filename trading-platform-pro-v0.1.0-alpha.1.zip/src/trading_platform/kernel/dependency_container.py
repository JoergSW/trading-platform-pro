class Container:
    def __init__(self):
        self._services={}
    def register(self,name,obj):
        self._services[name]=obj
    def resolve(self,name):
        return self._services[name]
