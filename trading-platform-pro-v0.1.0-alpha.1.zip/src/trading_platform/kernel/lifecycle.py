from enum import Enum
class State(Enum):
    CREATED="created"
    RUNNING="running"
    STOPPED="stopped"
