
from pathlib import Path
import yaml

class ConfigurationService:
    def __init__(self, base_dir: Path):
        self.base_dir = base_dir
        self.settings = {}

    def load(self, profile: str):
        path = self.base_dir / f"{profile}.yaml"
        with path.open("r", encoding="utf-8") as f:
            self.settings = yaml.safe_load(f) or {}
        return self.settings
