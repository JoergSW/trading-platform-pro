
from .dependency_container import DependencyContainer

class Application:
    def __init__(self):
        self.container = DependencyContainer()
        self.started = False

    def start(self):
        self.started = True

    def shutdown(self):
        self.started = False
