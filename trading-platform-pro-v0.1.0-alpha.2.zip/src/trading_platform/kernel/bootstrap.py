
from pathlib import Path
from .application import Application
from .configuration import ConfigurationService
from trading_platform.shared.logging.logger import configure_logging

def bootstrap(config_dir: Path, profile="development"):
    configure_logging(config_dir / "logging.yaml")
    cfg = ConfigurationService(config_dir)
    cfg.load(profile)
    app = Application()
    app.container.register_singleton("configuration", cfg)
    app.start()
    return app
