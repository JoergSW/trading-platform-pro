
class DependencyContainer:
    def __init__(self):
        self._services = {}

    def register_singleton(self, key, instance):
        self._services[key] = instance

    def resolve(self, key):
        return self._services[key]
